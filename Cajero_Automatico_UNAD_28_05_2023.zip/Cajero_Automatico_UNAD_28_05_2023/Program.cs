﻿/*
Las operaciones disponibles en el cajero corresponden a:
Consulta de saldo.
Retiros, solo si el saldo es mayor a la cantidad solicitada y si no supera el tope diario de retiros establecidos por el banco.
Es decir que no podrá retirar más de dos millones de pesos diarios.
Transferencias entre cuentas del mismo banco, para ello debe validar si existe la cuenta destino.
Consulta de puntos ViveColombia
Canje de puntos ViveColombia
Nombre: Edisson Montes
Grupo: 213023_46
Programa: Ingeniería de Sistemas
Código Fuente: Autoría Propia

Link del video: 
https://youtu.be/7740WFSzWQk

*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cajero_Automatico_UNAD_28_05_2023
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string numCuentaCliente = ""; //cadena de caracteres
            string clave = "";
            int iteraciones = 0;
            int opcion = 0;
            double saldo = 3800500;
            double monto = 0;
            double nuevoSaldo;
            int canjePuntos;
            int puntos = 200;
            int nuevosPuntos;
            int cuentaTercero = 1111;

            while (numCuentaCliente != "unad" || clave != "0000") //Estructura de repetición

            {
                Console.Clear();

                Console.WriteLine("Cajero Automatico UNAD");

                Console.Write("\nDigite  su número de Cuenta : ");
                numCuentaCliente = Console.ReadLine();
                Console.Write("Ingrese la clave de su cuenta : ");
                clave = Console.ReadLine();
                if (numCuentaCliente != "unad" || clave != "0000")
                {
                    iteraciones++;
                    if (iteraciones == 3)
                    {
                        Console.WriteLine("Clave errada más de 3 veces. Su Cuenta está Bloqueada.");
                        Console.WriteLine("Comuniquese a las líneas Nacionales de atención al Usuario de la UNAD ");

                        Console.ReadLine();
                        return;

                    }
                }
            }

            do //Bucle repeticion condicional
            {
                do
                {
                    Console.Clear();
                    Console.WriteLine("\nSeleccione Por Favor Una Operación :");
                    Console.WriteLine("1.Transeferencia a Otras Cuentas.");
                    Console.WriteLine("2.Consultar Saldo.");
                    Console.WriteLine("3.Canjear Puntos ViveColombia.");
                    Console.WriteLine("4.Retirar Dinero.");
                    Console.WriteLine("5.Salir");
                    Console.Write("Ingrese su opción : ");
                    opcion = int.Parse(Console.ReadLine());
                    if (opcion < 1 || opcion > 5)
                    {
                        Console.WriteLine("Error, Opción inválida.");
                        Console.ReadLine();
                        iteraciones++;
                        if (iteraciones == 3)
                        {
                            Console.WriteLine("Erró más de 3 veces, elija nuevamente una opción.");
                        }
                        break;//Detenemos el ciclo 
                    }
                }
                while (opcion < 1 || opcion > 5); //representa un valor booleano comparandolo

                switch (opcion)//Estructura de control de selección de Bloques 

                {
                    case 1://transeferir a otras cuentas
                        Console.Clear();
                        Console.WriteLine("Transferencia a Otras Cuentas.");
                        Console.Write("\nDigite número de cuenta : ");
                        cuentaTercero = int.Parse(Console.ReadLine());
                        Console.Write("Digite monto a transeferir : ");
                        monto = int.Parse(Console.ReadLine());
                        nuevoSaldo = (saldo - monto);
                        if (cuentaTercero == 1111)
                        {
                            if (nuevoSaldo > 0)
                            {
                                Console.WriteLine("Se Transfirió con Éxito cantidad {0} a la Cuenta Número {1}", monto, cuentaTercero);
                                Console.WriteLine("Su Actual Saldo es:" + nuevoSaldo);
                            }
                            else
                            {
                                Console.WriteLine("La operación no se puede realizar porque está sobre el saldo actual.");
                            }
                            Console.WriteLine("\nDigite 1 para realizar otra operación.");
                            Console.WriteLine("Digite 2 para Salir.");
                            Console.Write("Ingrese su opción : ");
                            opcion = int.Parse(Console.ReadLine());
                            if (opcion == 1)
                            {
                                break;
                            }
                            if (opcion == 2)
                            {
                                return;
                            }
                        }
                        else
                        {
                            Console.WriteLine("La cuenta NO Existe");
                        }
                        Console.WriteLine("\nPresione 1 para realizar otra operación.");
                        Console.WriteLine("Presione 2 para Salir.");
                        Console.Write("Ingrese su opción : ");
                        opcion = int.Parse(Console.ReadLine());
                        if (opcion == 1)
                        {
                            break;
                        }
                        if (opcion == 2)
                        {
                            return;
                        }
                        break;

                    case 2://Consultar Saldo y Puntos ViveColombia
                        Console.Clear();
                        Console.WriteLine("Consultar Saldo.");
                        Console.WriteLine("\nSu saldo actual es :{0} - Sus puntos son:{1} ViveColombia", saldo, puntos);
                        Console.WriteLine("\nDigite 1 para realizar otra operación.");
                        Console.WriteLine("Digite 2 para Salir.");
                        Console.Write("Ingrese su opción : ");
                        opcion = int.Parse(Console.ReadLine());
                        if (opcion == 1)
                        {
                            break;
                        }
                        if (opcion == 2)
                        {
                            return;
                        }
                        break;

                    case 3://Canjear Puntos ViveColombia
                        Console.Clear();
                        Console.WriteLine("Canje de Puntos ViveColombia");
                        Console.Write("\nIngrese la cantidad de puntos a Canjear: ");
                        canjePuntos = int.Parse(Console.ReadLine());

                        if (canjePuntos <= puntos)
                        {
                            Console.WriteLine("Se realizó con éxito el canje de {0} ViveColombia a su cuenta.", canjePuntos);
                            nuevosPuntos = (puntos - canjePuntos);
                            Console.WriteLine("Actualmente cuenta con {0} puntos ViveColombia", nuevosPuntos);
                        }
                        else
                        {
                            Console.WriteLine("No cuenta con los puntos suficientes para canjear");
                            Console.WriteLine("Actualmente cuenta con {0} puntos ViveColombia", puntos);
                        }
                        Console.WriteLine("\nPresione 1 para realizar otra operación.");
                        Console.WriteLine("Presione 2 para Salir.");
                        Console.Write("Ingrese su opción : ");
                        opcion = int.Parse(Console.ReadLine());
                        if (opcion == 1)
                        {
                            break;
                        }
                        if (opcion == 2)
                        {
                            return;
                        }
                        break;
                    case 4://Retiro de Dinero
                        Console.Clear();
                        Console.WriteLine("Retiro de Dinero.");
                        Console.Write("\nDigite cantidad de dinero a Retirar : ");
                        monto = int.Parse(Console.ReadLine());
                        nuevoSaldo = (saldo - monto);

                        if (monto <= 2000000)
                        {
                            if (saldo > 0)
                            {
                                nuevoSaldo = saldo - monto;
                                Console.WriteLine("Por Favor Retire Su Dinero!");
                                Console.WriteLine("Su Actual Saldo es: " + nuevoSaldo);

                                Console.WriteLine("\nDigite 1 para realizar otra operación.");
                                Console.WriteLine("Digite 2 para Salir.");
                                Console.Write("Ingrese su opción : ");
                                opcion = int.Parse(Console.ReadLine());
                                if (opcion == 1)
                                {
                                    break;
                                }
                                if (opcion == 2)
                                {
                                    return;
                                }
                            }

                            else
                            {
                                Console.WriteLine("La operación no se puede realizar porque está sobre el saldo actual.");
                            }
                            Console.WriteLine("\nDigite 1 para realizar otra operación.");
                            Console.WriteLine("Digite 2 para Salir.");
                            Console.Write("Ingrese su opción : ");
                            opcion = int.Parse(Console.ReadLine());
                            if (opcion == 1)
                            {
                                break;
                            }
                            if (opcion == 2)
                            {
                                return;
                            }
                        }
                        else
                        {
                            Console.WriteLine("El Monto {0} Supera la Cantidad Permitida", monto);
                        }
                        Console.WriteLine("\nPresione 1 para realizar otra operación.");
                        Console.WriteLine("Presione 2 para Salir.");
                        Console.Write("Ingrese su opción : ");
                        opcion = int.Parse(Console.ReadLine());
                        if (opcion == 1)
                        {
                            break;
                        }
                        if (opcion == 2)
                        {
                            return;
                        }
                        break;

                    case 5://salir
                        break;
                }
            } while (opcion != 5);

            Console.Write("Gracias por utilizar Nuestro cajero UNAD");
            Console.ReadLine();
            return;
        }
    }
}
